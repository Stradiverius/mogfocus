local _, M = ...
M.changelog = {
    { version = "0.3.0", date = "2026-10-31", features = "CHANGE_030_FEATURES", changes = "CHANGE_030_CHANGES", fixes = "CHANGE_030_FIXES" },
    { version = "0.2.1", date = "2026-10-23", features = "CHANGE_021_FEATURES", changes = "CHANGE_021_CHANGES", fixes = "CHANGE_021_FIXES" },
    { version = "0.2.0", date = "2026-10-23", features = "CHANGE_020_FEATURES", changes = "CHANGE_020_CHANGES", fixes = "CHANGE_020_FIXES" },
    { version = "0.1.0", date = "2026-10-23", features = "CHANGE_010_FEATURES", changes = "CHANGE_010_CHANGES", fixes = "CHANGE_010_FIXES" },
}
