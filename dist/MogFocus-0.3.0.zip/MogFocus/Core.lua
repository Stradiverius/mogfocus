local addon, M = ...
local events = CreateFrame("Frame")
local refreshing, catalogTimer

function M:Debug()
    local version, build, _, interface = GetBuildInfo()
    self:Print(self.L("VERSION", self.version) .. " · " .. self.L("DIAGNOSTIC", version, build, tostring(interface)))
    for _, spec in ipairs({ { "C_TransmogSets", "GetAllSets" }, { "C_TransmogSets", "GetSetInfo" },
        { "C_TransmogSets", "GetSetPrimaryAppearances" }, { "C_TransmogSets", "GetVariantSets" },
        { "C_TransmogCollection", "GetSourceInfo" }, { "C_TransmogCollection", "GetAppearanceSources" },
        { "C_TransmogCollection", "GetAppearanceSourceDrops" }, { "Settings", "RegisterCanvasLayoutCategory" } }) do
        local available = _G[spec[1]] and type(_G[spec[1]][spec[2]]) == "function"
        self:Print(spec[1] .. "." .. spec[2] .. ": " .. self.L(available and "YES" or "NO"))
    end
    if self.lastAPIError then self:Print(self.lastAPIError .. ": " .. self.L("UNAVAILABLE")) end
    for _, stage in ipairs({ { "Profile", self.ready }, { "Fonts", self.Fonts.ready and not self.Fonts.fallback },
        { "Options", self.Options.ready }, { "Collections", self.Integration.collectionsReady }, { "UI", self.UI.ready } }) do
        self:Print(stage[1] .. ": " .. self.L(stage[2] and "YES" or "NO"))
    end
    for stage, err in pairs(self.setupErrors or {}) do self:Print(stage .. ": " .. err) end
    if self.Fonts.fallback then self:Print(self.L("FONT_FALLBACK")) end
    if self.Preview.lastError then self:Print("Preview: " .. self.Preview.lastError) end
end

function M:Notify(set)
    self:Message("NOTIFY", set.info.name)
    if self.Store.settings.sound then PlaySound(SOUNDKIT.UI_EPICLOOT_TOAST) end
end

function M:Message(key, value)
    self.noticeKey, self.noticeValue = key, value
    if not self.notice then
        self.notice = self.UI:Panel(UIParent); self.notice:SetSize(520, 65); self.notice:SetPoint("TOP", 0, -130)
        self.notice:SetFrameStrata("HIGH"); self.notice.text = self.UI:Text(self.notice, "", true)
        self.notice.text:SetPoint("TOPLEFT", 16, -12); self.notice.text:SetWidth(488)
    end
    self.notice.text:SetText(self.L(key, value)); self.notice:Show()
    self.noticeGeneration = (self.noticeGeneration or 0) + 1
    local generation = self.noticeGeneration
    C_Timer.After(5, function() if generation == self.noticeGeneration then self.notice:Hide() end end)
end

function M:Refresh(invalidate, isRetry)
    if not self.ready then return end
    if not isRetry then
        self.loadingAttempts = 0; self.loadingRetry = nil
        self.loadingGeneration = (self.loadingGeneration or 0) + 1
    end
    if invalidate then self.Collection:Invalidate() end
    local pending = false
    for _, set in ipairs(self.Collection:Selected()) do
        if set.status ~= "ready" then pending = true end
        self.Collection:Observe(set, function(result) self:Notify(result) end)
    end
    self.UI:Render()
    self.Preview:Refresh()
    if pending and self.UI.frame and self.UI.frame:IsShown() and not self.loadingRetry and (self.loadingAttempts or 0) < 4 then
        self.loadingAttempts = (self.loadingAttempts or 0) + 1
        self.loadingRetry = true
        local generation = self.loadingGeneration
        C_Timer.After(.5 * 2 ^ (self.loadingAttempts - 1), function()
            if generation ~= self.loadingGeneration then return end
            self.loadingRetry = nil
            if self.UI.frame and self.UI.frame:IsShown() then self:Refresh(true, true) end
        end)
    end
end

function M:QueueRefresh()
    if refreshing then return end
    refreshing = true
    C_Timer.After(.25, function() refreshing = false; self:Refresh(true) end)
end

function M:StartCatalog()
    if catalogTimer then return end
    self.Collection:BeginCatalog()
    self.UI:RenderCatalog() -- IDs are available before the optional source scan.
    catalogTimer = C_Timer.NewTicker(.06, function()
        if not self.UI.frame or not self.UI.frame:IsShown() or self.UI.view ~= "catalog" then
            catalogTimer:Cancel(); catalogTimer = nil; return
        end
        local more = self.Collection:ScanCatalogBatch()
        if not more or GetTime() - (self.lastCatalogRender or 0) >= .4 then
            self.lastCatalogRender = GetTime(); self.UI:RenderCatalog()
        end
        if not more then catalogTimer:Cancel(); catalogTimer = nil end
    end)
end

function M:Initialize()
    if not self.ready then
        local db, err = self.Store:Open(MogFocusDB, UnitGUID("player"))
        if not db then self.blocked = err; self:Print(self.L(err)); return end
        MogFocusDB = db
        if not C_TransmogSets or not C_TransmogSets.GetSetPrimaryAppearances or not C_TransmogCollection or not C_TransmogCollection.GetSourceInfo then
            self.blocked = "API_MISSING"; self:Print(self.L(self.blocked)); return
        end
        -- Data is available even when combat or a UI error defers a later stage.
        self.ready = true
        self:Refresh(true)
    end
    self.Fonts:Report()
    -- Each UI module owns its own completion flag and may finish on a retry.
    if not InCombatLockdown() then self.Options:Register(); self.Integration:Update() end
end

events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
for _, event in ipairs({ "TRANSMOG_COLLECTION_UPDATED", "TRANSMOG_COLLECTION_SOURCE_ADDED", "TRANSMOG_COLLECTION_SOURCE_REMOVED",
    "TRANSMOG_COLLECTION_ITEM_UPDATE", "TRANSMOG_SOURCE_COLLECTABILITY_UPDATE", "ITEM_DATA_LOAD_RESULT", "UNIT_MODEL_CHANGED" }) do events:RegisterEvent(event) end

events:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 == addon and IsLoggedIn() then M:Initialize() end
        if arg1 == "Blizzard_Collections" and M.ready then M.Integration:Update() end
    elseif event == "PLAYER_LOGIN" then M:Initialize()
    elseif event == "PLAYER_REGEN_ENABLED" then M:Initialize()
    elseif M.ready then
        if event == "UNIT_MODEL_CHANGED" and arg1 ~= "player" then return end
        if event == "UNIT_MODEL_CHANGED" then M.Preview:UnitChanged() end
        if event == "ITEM_DATA_LOAD_RESULT" and not M.Collection.requested[arg1] then return end
        -- A catalog with pending source responses gets another bounded, visible-only pass.
        if event ~= "UNIT_MODEL_CHANGED" and event ~= "ITEM_DATA_LOAD_RESULT" then M.Collection.scanList = nil end
        M:QueueRefresh()
        if M.UI.view == "catalog" and M.UI.frame and M.UI.frame:IsShown() then M:StartCatalog() end
    end
end)

SLASH_MOGFOCUS1 = "/mogfocus"
SlashCmdList.MOGFOCUS = function(message)
    local command = string.lower((message or ""):match("^%s*(.-)%s*$"))
    if command == "debug" then M:Debug()
    elseif command == "catalogcheck" then
        if not M.ready then M:Print(M.L(M.blocked or "NO_PROFILE")); return end
        local count, missing = M.Collection:AuditCatalog()
        M:Print(M.L("CATALOG_AUDIT", count, #missing))
        if #missing > 0 then
            local ids = {}; for _, id in ipairs(missing) do ids[#ids + 1] = tostring(id) end
            M:Print(table.concat(ids, ", "))
        end
    elseif command == "options" then M.Options:Open()
    else M.UI:Toggle() end
end
